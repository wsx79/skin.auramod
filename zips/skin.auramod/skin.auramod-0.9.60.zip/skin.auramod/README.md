This is My modfications and fix's for the Auramod Skin .. Auramod mod if you so like to call it :)

This is kodi 18 version if you want the kodi 19 (matrix) version please switch to Matrix branch > https://github.com/SerpentDrago/skin.auramod/tree/Matrix
